using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class RoleController : ControllerBase
{
    private readonly IRoleService _roleService;

    public RoleController(IRoleService roleService)
    {
        _roleService = roleService;
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreateRole([FromBody] RoleCreateDto dto)
    {
        var result = await _roleService.CreateRoleAsync(dto);
        return result.Succeeded ? Ok("Role created") : BadRequest(result.Errors);
    }

    [HttpPut("update")]
    public async Task<IActionResult> UpdateRole([FromBody] RoleUpdateDto dto)
    {
        var result = await _roleService.UpdateRoleAsync(dto);
        return result.Succeeded ? Ok("Role updated") : BadRequest(result.Errors);
    }

    [HttpDelete("delete/{id}")]
    public async Task<IActionResult> DeleteRole(string id)
    {
        var result = await _roleService.DeleteRoleAsync(id);
        return result.Succeeded ? Ok("Role deleted") : BadRequest(result.Errors);
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAllRoles()
    {
        var roles = await _roleService.GetAllRolesAsync();
        return Ok(roles);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetRoleById(string id)
    {
        var role = await _roleService.GetRoleByIdAsync(id);
        return role == null ? NotFound("Role not found") : Ok(role);
    }
}
