public class RoleCreateDto
{
    public string Name { get; set; }
}