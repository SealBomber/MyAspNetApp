public class RoleUpdateDto
{
    public string Id { get; set; }
    public string NewName { get; set; }
}