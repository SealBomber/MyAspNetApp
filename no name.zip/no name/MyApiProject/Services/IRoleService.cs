using Microsoft.AspNetCore.Identity;

public interface IRoleService
{
    Task<IEnumerable<IdentityRole>> GetAllRolesAsync();
    Task<IdentityRole> GetRoleByIdAsync(string id);
    Task<IdentityResult> CreateRoleAsync(RoleCreateDto dto);
    Task<IdentityResult> UpdateRoleAsync(RoleUpdateDto dto);
    Task<IdentityResult> DeleteRoleAsync(string id);
}