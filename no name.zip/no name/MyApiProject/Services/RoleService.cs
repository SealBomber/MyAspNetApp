using Microsoft.AspNetCore.Identity;

public class RoleService : IRoleService
{
    private readonly RoleManager<IdentityRole> _roleManager;

    public RoleService(RoleManager<IdentityRole> roleManager)
    {
        _roleManager = roleManager;
    }

    public async Task<IEnumerable<IdentityRole>> GetAllRolesAsync()
    {
        return _roleManager.Roles.ToList();
    }

    public async Task<IdentityRole> GetRoleByIdAsync(string id)
    {
        return await _roleManager.FindByIdAsync(id);
    }

    public async Task<IdentityResult> CreateRoleAsync(RoleCreateDto dto)
    {
        return await _roleManager.CreateAsync(new IdentityRole(dto.Name));
    }

    public async Task<IdentityResult> UpdateRoleAsync(RoleUpdateDto dto)
    {
        var role = await _roleManager.FindByIdAsync(dto.Id);
        if (role == null)
            return IdentityResult.Failed(new IdentityError { Description = "Role not found" });

        role.Name = dto.NewName;
        return await _roleManager.UpdateAsync(role);
    }

    public async Task<IdentityResult> DeleteRoleAsync(string id)
    {
        var role = await _roleManager.FindByIdAsync(id);
        if (role == null)
            return IdentityResult.Failed(new IdentityError { Description = "Role not found" });

        return await _roleManager.DeleteAsync(role);
    }
}
