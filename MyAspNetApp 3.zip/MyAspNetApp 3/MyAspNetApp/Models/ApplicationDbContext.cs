using System.Data.Entity;

public class ApplicationDbContext : DbContext
{
    public DbSet<Product> Products { get; set; }
    public DbSet<CartItem> CartItems { get; set; }
    public DbSet<PromoCode> PromoCodes { get; set; }
}
