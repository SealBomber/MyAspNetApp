using System.Linq;
using System.Web.Mvc;

public class CartController : Controller
{
    private ApplicationDbContext _context = new ApplicationDbContext();

    public ActionResult Checkout(string promoCode)
    {
        var cartItems = Session["Cart"] as List<CartItem>;

        if (cartItems == null || !cartItems.Any())
            return RedirectToAction("Index");

        decimal discount = 0;

        if (!string.IsNullOrEmpty(promoCode))
        {
            var promo = _context.PromoCodes.FirstOrDefault(p => p.Code == promoCode);
            if (promo != null && promo.IsActive)
            {
                discount = promo.DiscountPercentage / 100m;
            }
        }

        decimal totalAmount = cartItems.Sum(item => item.Product.Price * item.Quantity);
        totalAmount -= totalAmount * discount;

        foreach (var item in cartItems)
        {
            var product = _context.Products.Find(item.Product.Id);
            if (product != null && product.Stock >= item.Quantity)
            {
                product.Stock -= item.Quantity;
            }
        }

        _context.SaveChanges();

        Session["Cart"] = null;

        return View("OrderConfirmation", totalAmount);
    }
}
