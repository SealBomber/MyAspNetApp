public class ChatDto
{
    public string Title { get; set; }
}
