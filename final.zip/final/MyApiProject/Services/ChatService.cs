public class ChatService : IChatService
{
    private readonly AppDbContext _context;

    public ChatService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<Chat> CreateChatAsync(ChatDto dto)
    {
        var chat = new Chat { Title = dto.Title };
        _context.Chats.Add(chat);
        await _context.SaveChangesAsync();
        return chat;
    }

    public async Task<IEnumerable<Chat>> GetAllChatsAsync()
    {
        return await _context.Chats.Include(c => c.Messages).ToListAsync();
    }

    public async Task<Chat> GetChatByIdAsync(int id)
    {
        return await _context.Chats.Include(c => c.Messages).FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task DeleteChatAsync(int id)
    {
        var chat = await _context.Chats.FindAsync(id);
        if (chat != null)
        {
            _context.Chats.Remove(chat);
            await _context.SaveChangesAsync();
        }
    }
}
