public interface IChatService
{
    Task<Chat> CreateChatAsync(ChatDto dto);
    Task<IEnumerable<Chat>> GetAllChatsAsync();
    Task<Chat> GetChatByIdAsync(int id);
    Task DeleteChatAsync(int id);
}
