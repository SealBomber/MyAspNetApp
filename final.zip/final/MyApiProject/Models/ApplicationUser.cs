public class ApplicationUser : IdentityUser
{
    public ICollection<Message> Messages { get; set; }
}
