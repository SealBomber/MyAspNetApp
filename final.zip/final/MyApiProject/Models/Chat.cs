public class Chat
{
    public int Id { get; set; }
    public string Title { get; set; }
    public ICollection<Message> Messages { get; set; }
}
