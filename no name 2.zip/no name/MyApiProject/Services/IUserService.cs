using Microsoft.AspNetCore.Identity;

public interface IUserService
{
    Task<IEnumerable<IdentityUser>> GetAllUsersAsync();
    Task<IdentityUser> GetUserByIdAsync(string id);
    Task<IdentityResult> CreateUserAsync(UserCreateDto dto);
    Task<IdentityResult> UpdateUserAsync(UserUpdateDto dto);
    Task<IdentityResult> DeleteUserAsync(string id);
}