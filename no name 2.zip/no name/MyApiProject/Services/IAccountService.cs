public interface IAccountService
{
    Task<IdentityResult> ConfirmEmailAsync(string userId, string token);
}